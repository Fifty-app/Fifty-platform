import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { ArrowRight, Building2, HandshakeIcon, TrendingUp, Users } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="h-8 w-8 text-rose-600" />
            <span className="text-2xl font-bold">Fifty</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#recursos" className="text-sm hover:text-rose-600 transition">Recursos</a>
            <a href="#como-funciona" className="text-sm hover:text-rose-600 transition">Como Funciona</a>
            <a href="#precos" className="text-sm hover:text-rose-600 transition">Preços</a>
          </nav>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <Link href="/forum">
                <Button>Acessar Plataforma</Button>
              </Link>
            ) : (
              <>
                <a href={getLoginUrl()}>
                  <Button variant="ghost">Entrar</Button>
                </a>
                <a href={getLoginUrl()}>
                  <Button>Começar Agora</Button>
                </a>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-slate-900 to-rose-600 dark:from-white dark:to-rose-400 bg-clip-text text-transparent">
            Divida Comissões, Multiplique Ganhos
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 mb-8 max-w-2xl mx-auto">
            A plataforma que conecta corretores de imóveis para compartilhar oportunidades e fechar mais negócios juntos.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href={getLoginUrl()}>
              <Button size="lg" className="text-lg px-8">
                Começar Gratuitamente
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </a>
            <a href="#como-funciona">
              <Button size="lg" variant="outline" className="text-lg px-8">
                Ver Como Funciona
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="recursos" className="container mx-auto px-4 py-20 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Por que escolher a Fifty?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <Users className="h-12 w-12 text-rose-600 mb-4" />
                <CardTitle>Rede de Corretores</CardTitle>
                <CardDescription>
                  Conecte-se com outros corretores e amplie suas oportunidades de negócio
                </CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <HandshakeIcon className="h-12 w-12 text-rose-600 mb-4" />
                <CardTitle>Divisão Justa</CardTitle>
                <CardDescription>
                  Sistema transparente para dividir comissões e fechar parcerias
                </CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <TrendingUp className="h-12 w-12 text-rose-600 mb-4" />
                <CardTitle>Mais Vendas</CardTitle>
                <CardDescription>
                  Aumente seu faturamento colaborando com outros profissionais
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="como-funciona" className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Como Funciona
          </h2>
          <div className="space-y-8">
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-rose-600 text-white flex items-center justify-center font-bold text-xl">
                1
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Cadastre-se com seu CRECI</h3>
                <p className="text-slate-600 dark:text-slate-400">
                  Crie sua conta gratuitamente usando seu número de CRECI. Validamos sua credencial em até 48h.
                </p>
              </div>
            </div>
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-rose-600 text-white flex items-center justify-center font-bold text-xl">
                2
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Publique ou Encontre Oportunidades</h3>
                <p className="text-slate-600 dark:text-slate-400">
                  Compartilhe necessidades de clientes ou encontre imóveis perfeitos para seus compradores.
                </p>
              </div>
            </div>
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-rose-600 text-white flex items-center justify-center font-bold text-xl">
                3
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Feche Negócios e Divida Comissões</h3>
                <p className="text-slate-600 dark:text-slate-400">
                  Colabore com outros corretores, feche mais vendas e divida as comissões de forma justa.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="precos" className="container mx-auto px-4 py-20 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Planos para Todos os Perfis
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Pessoa Física</CardTitle>
                <CardDescription>Para corretores autônomos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <span className="text-4xl font-bold">Grátis</span>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Acesso ao fórum de oportunidades</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Publicar demandas ilimitadas</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Sistema de propostas</span>
                  </li>
                </ul>
                <a href={getLoginUrl()}>
                  <Button className="w-full">Começar Agora</Button>
                </a>
              </CardContent>
            </Card>

            <Card className="border-rose-600 border-2">
              <CardHeader>
                <CardTitle className="text-2xl">PF Premium</CardTitle>
                <CardDescription>Para corretores avançados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <span className="text-4xl font-bold">R$ 97</span>
                  <span className="text-slate-600 dark:text-slate-400">/mês</span>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Tudo do plano Free</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Destaque nas oportunidades</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Suporte prioritário</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Relatórios avançados</span>
                  </li>
                </ul>
                <a href={getLoginUrl()}>
                  <Button className="w-full">Assinar Premium</Button>
                </a>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Pessoa Jurídica</CardTitle>
                <CardDescription>Para imobiliárias pequenas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <span className="text-4xl font-bold">R$ 297</span>
                  <span className="text-slate-600 dark:text-slate-400">/mês</span>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Tudo do plano PF</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Até 5 corretores</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Gestão de equipe</span>
                  </li>
                </ul>
                <a href={getLoginUrl()}>
                  <Button className="w-full">Começar Agora</Button>
                </a>
              </CardContent>
            </Card>

            <Card className="border-slate-600 border-2">
              <CardHeader>
                <CardTitle className="text-2xl">PJ Premium</CardTitle>
                <CardDescription>Para grandes imobiliárias</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <span className="text-4xl font-bold">Sob Consulta</span>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Tudo do plano PJ</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Corretores ilimitados</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Relatórios avançados</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <span className="text-green-600 dark:text-green-400 text-xs">✓</span>
                    </div>
                    <span>Suporte dedicado</span>
                  </li>
                </ul>
                <a href={getLoginUrl()}>
                  <Button className="w-full" variant="outline">Entrar em Contato</Button>
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-slate-50 dark:bg-slate-900/50 py-12">
        <div className="container mx-auto px-4 text-center text-slate-600 dark:text-slate-400">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Building2 className="h-6 w-6 text-rose-600" />
            <span className="text-xl font-bold text-slate-900 dark:text-white">Fifty</span>
          </div>
          <p>© 2025 Fifty. Todos os direitos reservados.</p>
          <p className="text-sm mt-2">Plataforma para corretores de imóveis</p>
        </div>
      </footer>
    </div>
  );
}
