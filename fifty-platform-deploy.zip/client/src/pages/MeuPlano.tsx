import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SideMenu } from "@/components/SideMenu";
import { Building2, Check, X, Zap } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";

export default function MeuPlano() {
  const { isAuthenticated, user, logout } = useAuth();

  if (!isAuthenticated) {
    window.location.href = getLoginUrl();
    return null;
  }

  if (!user?.creci) {
    window.location.href = "/validar-creci";
    return null;
  }

  const planos = [
    {
      id: "pf-free",
      nome: "PF Free",
      tipo: "Pessoa Física",
      preco: "Grátis",
      descricao: "Perfeito para começar",
      features: [
        { nome: "Publicar até 5 oportunidades/mês", incluido: true },
        { nome: "Cadastrar até 3 imóveis", incluido: true },
        { nome: "Enviar propostas ilimitadas", incluido: true },
        { nome: "Acesso ao fórum", incluido: true },
        { nome: "Suporte por email", incluido: true },
        { nome: "Relatórios avançados", incluido: false },
        { nome: "Destaque em oportunidades", incluido: false },
        { nome: "Prioridade no suporte", incluido: false },
      ],
      atual: user.accountType === "free" && user.creciType === "F",
    },
    {
      id: "pf-premium",
      nome: "PF Premium",
      tipo: "Pessoa Física",
      preco: "R$ 99/mês",
      descricao: "Para profissionais ativos",
      features: [
        { nome: "Publicar oportunidades ilimitadas", incluido: true },
        { nome: "Cadastrar imóveis ilimitados", incluido: true },
        { nome: "Enviar propostas ilimitadas", incluido: true },
        { nome: "Acesso ao fórum", incluido: true },
        { nome: "Suporte por email e chat", incluido: true },
        { nome: "Relatórios avançados", incluido: true },
        { nome: "Destaque em oportunidades", incluido: true },
        { nome: "Prioridade no suporte", incluido: false },
      ],
      atual: user.accountType === "premium" && user.creciType === "F",
    },
    {
      id: "pj-free",
      nome: "PJ Free",
      tipo: "Pessoa Jurídica",
      preco: "Grátis",
      descricao: "Para empresas começarem",
      features: [
        { nome: "Publicar até 10 oportunidades/mês", incluido: true },
        { nome: "Cadastrar até 5 imóveis", incluido: true },
        { nome: "Enviar propostas ilimitadas", incluido: true },
        { nome: "Acesso ao fórum", incluido: true },
        { nome: "Suporte por email", incluido: true },
        { nome: "Relatórios avançados", incluido: false },
        { nome: "Destaque em oportunidades", incluido: false },
        { nome: "Prioridade no suporte", incluido: false },
      ],
      atual: user.accountType === "free" && user.creciType === "J",
    },
    {
      id: "pj-premium",
      nome: "PJ Premium",
      tipo: "Pessoa Jurídica",
      preco: "R$ 199/mês",
      descricao: "Para empresas em crescimento",
      features: [
        { nome: "Publicar oportunidades ilimitadas", incluido: true },
        { nome: "Cadastrar imóveis ilimitados", incluido: true },
        { nome: "Enviar propostas ilimitadas", incluido: true },
        { nome: "Acesso ao fórum", incluido: true },
        { nome: "Suporte por email e chat", incluido: true },
        { nome: "Relatórios avançados", incluido: true },
        { nome: "Destaque em oportunidades", incluido: true },
        { nome: "Prioridade no suporte", incluido: true },
      ],
      atual: user.accountType === "premium" && user.creciType === "J",
    },
  ];

  const planoAtual = planos.find(p => p.atual);
  const planosPorTipo = user.creciType === "F" 
    ? planos.filter(p => p.tipo === "Pessoa Física")
    : planos.filter(p => p.tipo === "Pessoa Jurídica");

  return (
    <div className="min-h-screen bg-slate-950">
      <header className="border-b border-slate-800 bg-slate-900 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <SideMenu />
            <Link href="/"><div className="flex items-center gap-2 cursor-pointer">
              <Building2 className="h-8 w-8 text-rose-500" />
              <span className="text-2xl font-bold text-white">Fifty</span>
            </div></Link>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/perfil"><Button variant="ghost" className="text-white hover:text-rose-400">Meu Perfil</Button></Link>
            <Button variant="ghost" className="text-white hover:text-rose-400" onClick={() => logout()}>Sair</Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Meu Plano</h1>
          <p className="text-slate-400">Gerencie sua assinatura e compare planos</p>
        </div>

        {/* Plano Atual */}
        {planoAtual && (
          <Card className="border-rose-500 bg-gradient-to-r from-slate-900 to-slate-800 mb-8">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-white text-2xl">{planoAtual.nome}</CardTitle>
                  <CardDescription>{planoAtual.descricao}</CardDescription>
                </div>
                <Badge className="bg-rose-500 text-white">Plano Atual</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <div className="text-4xl font-bold text-white mb-2">{planoAtual.preco}</div>
                  <p className="text-slate-400 mb-6">Renovação automática todos os meses</p>
                  <Button className="w-full bg-rose-500 hover:bg-rose-600">Gerenciar Assinatura</Button>
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-4">Benefícios Inclusos</h3>
                  <ul className="space-y-2">
                    {planoAtual.features.filter(f => f.incluido).map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-slate-300">
                        <Check className="h-4 w-4 text-green-500" />
                        {feature.nome}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Comparação de Planos */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">Comparar Planos</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {planosPorTipo.map((plano) => (
              <Card key={plano.id} className={`border-slate-800 ${plano.atual ? 'ring-2 ring-rose-500' : ''}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-white">{plano.nome}</CardTitle>
                      <CardDescription>{plano.descricao}</CardDescription>
                    </div>
                    {plano.atual && <Badge className="bg-rose-500">Atual</Badge>}
                  </div>
                  <div className="mt-4">
                    <div className="text-3xl font-bold text-white">{plano.preco}</div>
                    {plano.preco !== "Grátis" && <p className="text-sm text-slate-400">por mês</p>}
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    {plano.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        {feature.incluido ? (
                          <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        ) : (
                          <X className="h-5 w-5 text-slate-600 flex-shrink-0 mt-0.5" />
                        )}
                        <span className={feature.incluido ? "text-slate-300" : "text-slate-500 line-through"}>
                          {feature.nome}
                        </span>
                      </div>
                    ))}
                  </div>

                  {!plano.atual && (
                    <Button className="w-full bg-rose-500 hover:bg-rose-600">
                      {plano.preco === "Grátis" ? "Fazer Downgrade" : "Fazer Upgrade"}
                    </Button>
                  )}
                  {plano.atual && (
                    <Button variant="outline" disabled className="w-full">
                      Plano Atual
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Histórico de Pagamentos */}
        <Card className="border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">Histórico de Pagamentos</CardTitle>
            <CardDescription>Últimas transações da sua conta</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-slate-900 rounded-lg">
                <div>
                  <p className="text-white font-semibold">Assinatura {planoAtual?.nome}</p>
                  <p className="text-sm text-slate-400">Próximo pagamento em 15 dias</p>
                </div>
                <div className="text-right">
                  <p className="text-white font-semibold">{planoAtual?.preco}</p>
                  <Badge className="bg-green-500 text-white">Pago</Badge>
                </div>
              </div>
              <p className="text-center text-slate-400 text-sm">Nenhum outro pagamento anterior</p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
